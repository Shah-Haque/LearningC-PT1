﻿namespace Methods
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //for (int i = 0; i < 10; i++)
            //{
            //    SampleMethods.Helloworld();
            //}

            //Naming is crucial when creating methods

            // DRY - Don't Repeat Yourself
            // SOLID - SRP - Single Responsibllity Principle

            //ConsoleMessages.Helloworld();

            //string name = ConsoleMessages.GetUserName();

            //ConsoleMessages.Helloworld(name);

            //double result = MathShortcuts.Add(5, 3);
            //Console.WriteLine($"The result is {result}");

            //double[] vals = new double[]
            //{
            //    2,5,6,21,52,98
            //};

            //MathShortcuts.AddAll(vals);

            //Console.WriteLine();

            //ConsoleMessages.SayGoodbye();

            //tuple calling 
            // Discard character (_)
            (string firstname, _)  = ConsoleMessages.GetFullName();

            Console.WriteLine($"First Name : {firstname}");
           // Console.WriteLine($"Last Name : {name.lastname}");
        }
    }
}