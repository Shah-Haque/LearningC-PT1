﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods
{
    public static class ConsoleMessages
    {
        public static void Helloworld(string name)
        {
           
            Console.WriteLine($"hello {name}");
            Console.WriteLine("I hope you have a good day");
        }

     
        public static string GetUserName()
        {
            Console.Write("What is your name: ");
            string name = Console.ReadLine();

            return name;
        }  
        
        
        //  TUPLE
        public static (string firstname,string lastname) GetFullName()
        {
            Console.Write("What is your Firstname: ");
            string FirstName = Console.ReadLine();

            Console.Write("What is your Lastname: ");
            string LastName = Console.ReadLine();

            return (FirstName,LastName);
        }

        public static void SayGoodbye()
        {
            Console.WriteLine("Goodbye, user");
            Console.WriteLine("Thanks for visting");
            Console.WriteLine("I can't wait to see you again");
        }

    }
}
