﻿namespace ForLoops
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //for (int i = 0; i < 10; i++)
            //{
            //    Console.WriteLine($"The value of i is {i}");
            //}

            //string data = "Shah,Tim,Sue,Bob,Frank";

            //List<string> firstnames = data.Split(',').ToList();

            //for (int i = 0; i < firstnames.Count; i++)
            //{
            //    Console.WriteLine($"{firstnames[i]} is in attendance" );
            //}

            //List<decimal> charges = new();

            //charges.Add(11.23M);
            //charges.Add(12.55M);
            //charges.Add(11.23m);

            //decimal total = 0;

            //for (int i = 0; i < charges.Count; i++)
            //{
            //    total += charges[i];
            //}
            //Console.WriteLine($"our total charge is: {total}" );
        }
    }
}