﻿namespace intVariabless
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ints are whole numbers-they can't contain decimal or floating points

            int age = 0;

            age = 23;

            int ageinTenYears = age + 10;

            //ints can go up to two billion +/-
            //Ints has a variation called signed int32
            //Ints can be unsigned and can hold up to 4 billion
            //this is called Uint
            //bits are 0 and 1
            //bytes - 8 bits - 00000000
            //1, 11, 111
            //Ints work well with addition, subtraction and multiplication
            //it does not work with division as if the number is an float that
            //number would be rounded to the nearest number

            Console.WriteLine(ageinTenYears);
        }
    }
}