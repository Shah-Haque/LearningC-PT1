﻿namespace DecimalVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Decimals are more accurate then floats
            //It takes up more memory then floats 
            //Decimals can store values such as 4.12, 32, 1.234
  
            //name of the variable we using
            decimal bankAccountBalance;

            //To Declare a decimal value you must add the value you want and
            //then put m on the end of the number example 2.5 -> 2.5m
            bankAccountBalance = 8000434/25.4m;

            bankAccountBalance = bankAccountBalance * 20m;

            //This prints the balance in the console
            Console.WriteLine(bankAccountBalance);

        }
    }
}