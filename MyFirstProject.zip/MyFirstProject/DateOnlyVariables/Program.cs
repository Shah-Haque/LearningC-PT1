﻿namespace DateOnlyVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTime today = DateTime.Now;

            DateOnly birthday = DateOnly.Parse("18/05/1999");

            Console.WriteLine(birthday.ToString(format: "dd MMMM, yyyy"));

            Console.WriteLine($"Today full format: {today}");

            Console.WriteLine($"Today just date: {today.Date}");

        }
    }
}