﻿namespace DoubleVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //doubles can be a whole number or a floating point - 1.23, 43

            //Variable averageAge which is a double
            double averageAge;

            //Value of average is this calculation
            //averageAge = (1000 - 500 * 5 + 10) / 3;

            averageAge = 123.5 / 3;

            averageAge = averageAge / 2;

            //Prints the answer in the console
            Console.WriteLine(averageAge);



        }
    }
}