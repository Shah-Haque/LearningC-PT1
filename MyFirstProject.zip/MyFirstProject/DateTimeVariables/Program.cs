﻿using System.Globalization;

namespace DateTimeVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //This brings the current date time
            //DateTime today = DateTime.Now;

            //This brings the current universal date time
            DateTime today = DateTime.UtcNow;

            //This parses the variable using the computer date format
            //DateTime Birthday = DateTime.Parse(s:"18/12/1999");

            //This is a custom parse where the date is parsed exactly as we specifiy for it to be 
            //the date will be shown as thr 6th november 1998, with the day being a single digit,
            //the month having a value and the year four values
            //CultureInfo provides infromation for a specific culture that has their own style of date format
            //we are using the invariantculture method which gives our object its own independent date format
            //DateTime birthday = DateTime.ParseExact("6/11/1998", "d/M/yyyy", CultureInfo.InvariantCulture);

            //This prints the variable in the console 
            //The letters inside the blue bracers specify what format does the console need to print the datetime
            Console.WriteLine(today.ToString("MMMM dd, yyyy hh:mm tt zzz "));
          


        }
    }
}