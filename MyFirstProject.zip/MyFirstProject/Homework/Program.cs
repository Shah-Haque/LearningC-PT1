﻿namespace Homework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string Name;
            int age;
            bool areyoualive = true;
            string phonenumber;

            Console.Write("What is your name: ");
            Name = Console.ReadLine();

            Console.WriteLine("How old are you: ");
            Console.WriteLine(age.ToString());

            Console.WriteLine(areyoualive);
            Console.Write("What is your PhoneNumber: ");
            phonenumber = Console.ReadLine();
           

        }
    }
}