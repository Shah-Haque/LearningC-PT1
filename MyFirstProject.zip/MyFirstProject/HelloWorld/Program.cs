﻿//cw is the shortcut to autogenerate console writeline
//Console.WriteLine is the method signature



Console.WriteLine("Hello, World!");

Console.WriteLine("How are you?");

Console.WriteLine("My Name is Shah Haque, What is your Name?");

Console.WriteLine();

Console.WriteLine("Nice to meet You!!!");

Console.Read();