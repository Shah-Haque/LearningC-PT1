﻿namespace nulls
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Null means a lack of values

            //This is age variable which is null as it lacks values
            //We haven't asked for the age yet
            //the question mark on the datatype makes the variable
            //a nullable type meaning it can accept no values in a variable
            //Datatypes that can be nullable are:
            //string?
            //double?

            int? age = null;
            //
            //we haven't asked for age now
            age= 20 - 3;

            //This prints the age into the console
            Console.WriteLine(age);


        }
    }
}