﻿namespace Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //0 based counting 0,1,2,3,4
            //1 based counting 1,2,3,4,5
            //string[] firstname = new string[6];

            //firstname[0] = "Aaron";
            //firstname[1] = "Brittany";
            //firstname[2] = "Connor";
            //firstname[3] = "Daniel";
            //firstname[4] = "Emily";
            //firstname[5] = "Freddie";

            //Console.WriteLine($"the firstnames are {firstname[0]},{firstname[1]}," +
            //    $" {firstname[2]}, {firstname[3]}, {firstname[4]}, {firstname[5]}");

            //firstname[6] = "Timothy";
            //Console.WriteLine(firstname[0]);

            //single quote means a char
            //double quotes idenitfy a string

            string data = "Shah,Sue,Bob,Mary,Tim";
            string[] firstnames = data.Split(',');

            Console.WriteLine(firstnames[firstnames.Length - 2]);

            Console.WriteLine(firstnames.Length);

            string[] secondnames = new string[] { "Haque", "Smith", "Jones", "Jane", "Corey" };
            int[] ages = new int[] { 2, 3, 4 };

        }
    }
}