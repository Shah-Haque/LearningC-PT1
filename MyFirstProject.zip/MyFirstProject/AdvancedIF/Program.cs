﻿namespace AdvancedIF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.Write("What is your First name: ");
            //string firstname = Console.ReadLine();

            //Console.Write("What is your last name: ");
            //string lastname = Console.ReadLine();

            //if (firstname.ToLower() == "shah" 
            //    && lastname.ToLower() == "haque")
            //{
            //    Console.WriteLine("My wife left me");
            //}
            ////|| means or
            //else if(firstname.ToLower() == "shah" || 
            //        lastname.ToLower() == "Haque")
            //{
            //    Console.WriteLine("Based");
            //}
            //else
            //{
            //    Console.WriteLine("common L");
            //}

            int age = 73;
            //you can use parenthesise to change of how the compiler
            //can go about printing the answer
            //to the console

            //you can do this by:
            //if ((age >= 40 && age < 50) || 
            //    (age >= 70 && age < 80))
            //{
            //    Console.WriteLine("Bing Chilling");
            //}

            ////Or like this

            //if (age >= 40 && (age < 50) ||
            //   (age >= 70) && age < 80)
            //{
            //    Console.WriteLine("Bing Chilling");
            //}




            ////If both first and last names are true
            //if (firstname.ToLower() == "shah" &&
            //    lastname.ToLower() == "haque")
            //{
            //    Console.WriteLine(value: "hello shah haque");
            //}
            //else if (firstname.ToLower() == "shah")
            //{
            //    Console.WriteLine(value: "Hello you have a cool name");
            //}
            //else if (lastname.ToLower() == "haque")
            //{
            //    Console.WriteLine(value: "You have a great lastname");
            //}
            //else 
            //{
            //    Console.WriteLine("Sorry you don't work");
            //}
            ////int age = 69;

            //if (age != 43)
            //{
            //    Console.WriteLine("ratio lmao");
            //}
            // == means equal, > means greater than , >= means greater or equal to, <= means less than or equal to
            //!= means not equal to (Bang operator)
            //if (age >= 40 && age < 50)
            //{
            //    Console.WriteLine("okay boomer");
            //}
        }
    }
}