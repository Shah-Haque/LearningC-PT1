﻿namespace Homework2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int userAge;

            Console.Write("How old would you be in 25 Years: ");

            userAge = int.Parse(Console.ReadLine());

            Console.WriteLine(userAge);

        }
    }
}