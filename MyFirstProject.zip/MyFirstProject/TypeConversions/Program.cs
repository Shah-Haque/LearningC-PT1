﻿namespace TypeConversions
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("What is your age: ");
            string? agetext = Console.ReadLine();
            
            //int age = int.Parse(agetext);

            bool isValidInt = int.TryParse(agetext, out int age);

            Console.WriteLine($"This is Valid: {isValidInt}. Then Number was {age}");

            Console.WriteLine(age + 22);


            //This is casting look at the decimal in in testdecimal variable
            double testdouble = age;
            decimal testdecimal = (decimal)testdouble;
        }
    }
}