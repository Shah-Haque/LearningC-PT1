﻿
namespace Greetings
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Welcome user to application
            Console.WriteLine("Hello, User!!!!!");
            Console.WriteLine("Welcome to my Greeting Application....");
            Console.WriteLine("This was made by Shah Haque!!!!!");
            Console.WriteLine("-----------------------------");
            Console.WriteLine();

            //Ask for the firstName
            Console.Write("What is your FirstName: ");    
            string firstName;
            firstName = Console.ReadLine();

            //Ask for LastName
            Console.Write("What is your lastName: ");
            string lastName;
            lastName = Console.ReadLine();

            //Great user by firstname and lastname
            Console.WriteLine("Greetings: " + firstName + lastName);   
            Console.WriteLine("-----------------------------");
            Console.WriteLine();
       

            //exit the application 
            Console.WriteLine("Thank you for using my application!!");
            Console.WriteLine("Have a Great Day !!!!!!!!!!!!!!");
            Console.WriteLine("-----------------------------");
            Console.ReadLine();

        }
    }
}