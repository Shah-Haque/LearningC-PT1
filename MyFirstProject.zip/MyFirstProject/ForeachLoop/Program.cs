﻿namespace ForeachLoop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string data = "Tim,Shah,Bob,Jane";
            List<string> Firstnames =data.Split(',').ToList();

            foreach (string Firstname in Firstnames)
            {
                Console.WriteLine(Firstname);
            }

        }
    }
}