﻿namespace TimeOnlyVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TimeOnly opensAt = TimeOnly.Parse("8:00AM");

            TimeOnly rightNow = TimeOnly.FromDateTime(DateTime.Now);

            Console.WriteLine(opensAt);

            Console.WriteLine(rightNow);

        }
    }
}