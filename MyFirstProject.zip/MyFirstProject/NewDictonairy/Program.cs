﻿using System.Runtime.InteropServices;

namespace NewDictonairy
{
    internal class Program
    {
        static void Main(string[] args)
        {
           //This creates a new set of values and store it inside the variable
           //It has two types of values a key type and a value type

           //This will create a new dictionary which creates a int as a key and a string as the value 
           //This is defualt it can be any data type as long as it is represented in the look up value
           Dictionary<string, string> lookup = new Dictionary<string, string>();

            //These are the keys that are inside the lookup dictionary
            lookup["animal"] = "not a human";
            lookup["fish"] = "Not a human that swims";
            lookup["human"] = "us";

            //This prints out the defintion of fish through its key
            Console.WriteLine($"the definition of fish is {lookup["fish"]}");

            Dictionary<int, string> employee = new Dictionary<int, string>();

            employee[1001] = "Shah";
            employee[22] = "Tim";
            employee[1] = "Leon";

            Console.WriteLine($"the employee id with the number 1001 is: {employee[1001]}");


            //This is an example of the string being the key and the int is the value
            //A new dictionary class is created called dayof week
            Dictionary<string, int> dayofweek = new Dictionary<string, int>();

            //Dayofweek contains seven keys which are the days in a week
            dayofweek["Monday"] = 1;
            dayofweek["Tuesday"] = 2;
            dayofweek["Wednesday"] = 3;
            dayofweek["Thursday"] = 4;
            dayofweek["Friday"] = 5;
            dayofweek["Saturday"] = 6;
            dayofweek["Sunday"] = 7;

            //This prints out wednesday value through its string key "Wednesday"
            Console.WriteLine($"the day number on wednesday is: {dayofweek["Wednesday"]}");

            //You can't duplicate keys as it will override the previous key wityh the same value 

        }
    }
}