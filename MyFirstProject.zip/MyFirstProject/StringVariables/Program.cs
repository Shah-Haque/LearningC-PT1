﻿namespace StringVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variables hold information

            string firstName;
            string lastName;
            string filePath;

            firstName = "Shah";
            lastName = "Haque";
            //To add back slashes to strings you must use the two backslashes
            // filePath = "c:\\Temp\\Demo";
            filePath = @"C:\Temp\Demo"; // This is a string litral

            string basedSring = $@"File for {firstName} is at C:\Temp\Demo ";


            //string concatination
            //Console.WriteLine(firstName + " " + lastName);

            //string interpolation
            Console.WriteLine($"Hi There {firstName} {lastName}");
            Console.WriteLine(filePath);
            Console.WriteLine(basedSring);
        }
    }
}