﻿
namespace BasicIF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Attempt 1
            //bool isComplete = false;

            //if (isComplete)
            //{
            //    Console.WriteLine("The statement was true");
            //    Console.WriteLine("This also works in true");
            //}
            //else 
            //{ 
            //    Console.WriteLine("The statement was false");
            //    Console.WriteLine("This should also run");
            //}

            #endregion 


            Console.Write("What is your First Name: ");
            string? Firstname = Console.ReadLine();

            if (Firstname?.ToLower() == "shah")
            {
                Console.WriteLine("Hello shah!!!!!!!");

            }
            else 
            {
                Console.WriteLine($"Hello: {Firstname}");
            }
 
            Console.WriteLine("End of program");
        }
    }
}