﻿namespace DOWHILELOOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool isValidAge;
            int age;
            int testNumber = 0;

            #region do
            //do
            //{
            //    Console.Write(testNumber);
            //    testNumber += 3;

            //} while (testNumber < 10);

            //The do loop wil run the code at least once
            //This do loop will run the code below while the isvalidage is equal to false
            #endregion

            do
            {
                Console.Write("What is your Age: ");

                string ageText = Console.ReadLine();

                isValidAge = int.TryParse(ageText, out age);

                if (isValidAge == false)
                {
                    Console.Write("This is an invalid age");
                    return;
                }

            } while (isValidAge == false);

            Console.WriteLine($"Your age is {age}");



             //runs the code zero or more times
           



        }
    }
}