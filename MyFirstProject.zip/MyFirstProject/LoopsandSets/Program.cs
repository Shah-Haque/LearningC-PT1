﻿namespace Lists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //similar to string array = new new string[5]


            List<string> names = new List<string>();

            names.Add("aaeron");
            names.Add("Jamie");
            names.Add("Chloe");
            names.Add("shah");
            names.Add("dudley");
            names.Add("amy");

            Console.WriteLine(names[names.Count - 1]);

            //Lists work like this
            // List<T> - generic - the t is the type that the list contains 

            //string data = "Corey,Haque,Smith";
            //List<string> lastnames = data.Split(',').ToList();
            //lastnames.Add("Hudson");
        }
    }
}