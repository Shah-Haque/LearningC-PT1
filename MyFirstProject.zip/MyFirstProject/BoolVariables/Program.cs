﻿namespace BoolVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //bools have two values true or false
            //by default bools are set to true but can be turned into false
            //by expliciitly or implicitly stating that they are false

            //variable called isComplete which is set to false
            bool isComplete = false;

            //The exclmation point is called the not operator and it sets
            //a value to not be something so in this it is set to not false
            //You can also add the ! operator on the console statement
            //which will print the value as false
            isComplete = !isComplete;

            //prints out the value into the console
            Console.WriteLine(!isComplete);
        }
    }
}