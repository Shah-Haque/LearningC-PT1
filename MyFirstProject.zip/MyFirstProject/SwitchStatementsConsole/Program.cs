﻿namespace SwitchStatementsConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string firstname = "mary sue";
            int age = 29;
            switch (age)
            {
                case >= 0 and < 18:
                    Console.WriteLine("Okay Zoomer");
                    break;
                case >= 18 and < 66:
                    Console.WriteLine("what a loser get a job");
                    break;
                case >= 66:
                    Console.WriteLine("Retire you worker");
                    break;
                default:
                    Console.WriteLine("You are a manlet");
                    break;
            }
            //switch (firstname.ToLower())
            //{
            //    //case "tim":
            //    case "bussy" or "mary sue":
            //    case "shah":
            //        Console.WriteLine("REEEEEEEEEEEEE");
            //        break;
            //    case "lebron":
            //        Console.WriteLine("BRUHHHHHHHHHHHHHHHHHH");
            //        break;
            //    case "dabussy":
            //        Console.WriteLine("WRYYYYYYYYYYYYYYYYYYY");
            //        break;
            //    default: 
            //        Console.WriteLine("Most stable man in the west midlands");
            //        break;
            //}
        }
    }
}